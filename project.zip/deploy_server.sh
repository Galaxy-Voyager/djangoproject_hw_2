#!/bin/bash

set -e  # Прерывать выполнение при ошибках

echo "=== Начало деплоя Django LMS проекта ==="

# Переходим в директорию проекта
cd /home/voyager/djangoproject_hw_2

# Активируем виртуальное окружение
echo "[INFO] Активация виртуального окружения..."
source venv/bin/activate

# Обновляем зависимости
echo "[INFO] Обновление зависимостей..."
pip install --upgrade pip
pip install -r requirements.txt

# Применяем миграции
echo "[INFO] Применение миграций..."
python manage.py migrate --noinput

# Собираем статические файлы
echo "[INFO] Сбор статических файлов..."
python manage.py collectstatic --noinput --clear

# Создаем суперпользователя если его нет
echo "[INFO] Проверка суперпользователя..."
python manage.py shell -c "
from django.contrib.auth import get_user_model
User = get_user_model()
if not User.objects.filter(email='admin@example.com').exists():
    User.objects.create_superuser('admin@example.com', 'adminpassword')
    print('Суперпользователь создан')
else:
    print('Суперпользователь уже существует')
"

# Загружаем фикстуры
echo "[INFO] Загрузка фикстур..."
python manage.py loaddata groups.json

# Перезапускаем Gunicorn через systemd
echo "[INFO] Перезапуск Gunicorn..."
sudo systemctl restart gunicorn

# Перезапускаем Celery
echo "[INFO] Перезапуск Celery workers..."
sudo systemctl restart celery
sudo systemctl restart celerybeat

# Проверяем статус сервисов
echo "[INFO] Проверка статуса сервисов..."
sudo systemctl status gunicorn --no-pager
sudo systemctl status celery --no-pager
sudo systemctl status celerybeat --no-pager

echo "=== Деплой успешно завершен! ==="
echo "Приложение доступно по адресу: http://$(curl -s ifconfig.me):8000"
